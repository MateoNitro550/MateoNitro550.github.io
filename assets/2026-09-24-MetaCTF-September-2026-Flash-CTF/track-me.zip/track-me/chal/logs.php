<?php

$file = $_GET['file'] ?? 'home';

if ($file === 'home') {
    header('Content-Type: text/html; charset=utf-8');
    echo '<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>TrackMe Log Viewer</title><script src="https://cdn.tailwindcss.com"></script></head><body class="min-h-screen text-gray-800 bg-gray-50">';
    echo '<div class="container mx-auto max-w-3xl py-8 px-4"><div class="bg-white border border-gray-100 shadow-sm rounded-lg p-6">';
    echo '<div class="flex items-baseline justify-between mb-1"><h1 class="text-xl font-semibold">TrackMe Log Viewer</h1><a class="text-sm text-gray-500 hover:text-gray-800" href="/">Dashboard</a></div>';
    echo '<p class="text-sm text-gray-600 mb-4">Select a log file.</p>';
    echo '<ul class="text-sm"><li><a class="text-blue-600 hover:underline" href="?file=access.log">access.log</a></li></ul>';
    echo '</div></div></body></html>';
    exit;
}

// Safe log serving: do not use include(), do not execute PHP from logs
// Normalize filename and allow only simple names
// Re-enable include() but strictly restrict allowed files to prevent LFI
$logs_dir = realpath(__DIR__ . '/logs');
if ($logs_dir === false) {
    http_response_code(500);
    echo "Logs directory missing.";
    exit;
}

// Normalize filename and allow only simple names
$basename = basename($file);
if (!preg_match('/^[A-Za-z0-9._-]+$/', $basename)) {
    http_response_code(400);
    echo "Invalid file name.";
    exit;
}

// Build whitelist from actual files in the logs directory
$available = array_values(array_filter(scandir($logs_dir), function($f) use ($logs_dir) {
    $p = $logs_dir . DIRECTORY_SEPARATOR . $f;
    return is_file($p) && preg_match('/^[A-Za-z0-9._-]+$/', $f);
}));

if (!in_array($basename, $available, true)) {
    http_response_code(403);
    echo "Access denied or file not allowed.";
    exit;
}

$path = realpath($logs_dir . DIRECTORY_SEPARATOR . $basename);
if ($path === false || strpos($path, $logs_dir) !== 0) {
    http_response_code(403);
    echo "Access denied.";
    exit;
}

// Safe include: only include files that are explicitly present in the logs directory
// This allows PHP in logs to execute, but prevents path traversal and LFI.
// Note: ensure `allow_url_include` is disabled in PHP config on production.
// Buffered so the log lands in the viewer's own panel and nothing is written to the
// response before the headers below go out.
ob_start();
include $path;
$rendered = ob_get_clean();

// Render safely as preformatted, escaping any PHP or HTML
header('Content-Type: text/html; charset=utf-8');
$safe_name = htmlspecialchars($basename);
$safe_content = htmlspecialchars($rendered);
$line_count = substr_count($rendered, "\n");
$byte_count = strlen($rendered);
echo '<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Log: ' . $safe_name . '</title><script src="https://cdn.tailwindcss.com"></script></head><body class="min-h-screen text-gray-800 bg-gray-50">';
echo '<div class="container mx-auto max-w-3xl py-8 px-4"><div class="bg-white border border-gray-100 shadow-sm rounded-lg p-6">';
echo '<div class="flex items-baseline justify-between mb-1"><h1 class="text-xl font-semibold">TrackMe Log Viewer</h1><a class="text-sm text-gray-500 hover:text-gray-800" href="/">Dashboard</a></div>';
echo '<p class="text-sm text-gray-500 mb-4">' . $safe_name . ' &middot; ' . $line_count . ' lines &middot; ' . $byte_count . ' bytes</p>';
echo '<div class="rounded border border-gray-200 bg-gray-50 p-4 overflow-auto max-h-[32rem]"><pre class="whitespace-pre-wrap break-words font-mono text-xs leading-5 text-gray-700">' . $safe_content . '</pre></div>';
echo '<p class="mt-4 text-sm"><a class="text-blue-600 hover:underline" href="?file=home">Back to log list</a></p>';
echo '</div></div></body></html>';
