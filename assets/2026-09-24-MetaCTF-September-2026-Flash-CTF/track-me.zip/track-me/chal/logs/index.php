<?php
$files = array_diff(scandir(__DIR__), array('.', '..'));
?>
<!DOCTYPE html>
<html>
<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <title>Logs</title>
        <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen text-gray-800 bg-gray-50">
    <div class="container mx-auto max-w-xl py-12 px-4">
        <div class="bg-white border border-gray-100 shadow-sm rounded-lg p-6">
            <h1 class="text-xl font-semibold mb-4">Logs</h1>
            <ul class="list-disc list-inside space-y-2 text-sm text-gray-700">
                <?php foreach ($files as $f): ?>
                        <li><a class="text-blue-600 hover:underline" href="/<?php echo 'logs/' . urlencode($f); ?>"><?php echo htmlspecialchars($f); ?></a></li>
                <?php endforeach; ?>
            </ul>
            <p class="mt-4"><a class="text-sm text-gray-600" href="/logs.php">Log Viewer</a></p>
        </div>
    </div>
</body>
</html>
