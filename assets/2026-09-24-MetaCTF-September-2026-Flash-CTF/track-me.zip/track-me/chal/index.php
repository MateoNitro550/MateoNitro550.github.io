<?php

$ip = $_SERVER['REMOTE_ADDR'] ?? '-';
$ua = $_SERVER['HTTP_USER_AGENT'] ?? '-';
$time = date("Y-m-d H:i:s");
$method = $_SERVER['REQUEST_METHOD'] ?? '-';
$uri = $_SERVER['REQUEST_URI'] ?? '-';
$referer = $_SERVER['HTTP_REFERER'] ?? '-';

$log = "==== Visit ====\n";
$log .= "Time: $time\n";
$log .= "IP: $ip\n";
$log .= "Method: $method\n";
$log .= "URI: $uri\n";
$log .= "Referer: $referer\n";
$log .= "User-Agent: $ua\n";
$log .= "----------------\n\n";

file_put_contents(__DIR__ . "/logs/access.log", $log, FILE_APPEND);

?>

<!DOCTYPE html>
<html>
<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <title>TrackMe Analytics</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <style>
            body { background-color: #f8fafc; }
        </style>
</head>
<body class="min-h-screen text-gray-800">
    <div class="container mx-auto max-w-xl py-12 px-4">
        <div class="bg-white border border-gray-100 shadow-sm rounded-lg p-6">
            <h1 class="text-2xl font-semibold mb-2">TrackMe</h1>
            <p class="text-sm text-gray-600 mb-4">Your visit has been recorded.</p>
            <a href="/logs.php" class="inline-block px-4 py-2 bg-gray-100 text-gray-800 rounded hover:bg-gray-200">View Logs</a>
        </div>
    </div>
</body>
</html>