#!/bin/sh
set -eu

# The real flag is injected as an env var at deploy time, so it never lives in the
# image or in git. It is written outside DocumentRoot under a name drawn fresh on
# every container start, so there is no static path for anyone to request over HTTP.
# Do not fold this into ${FLAG:-...}: the shell ends the expansion at the first
# closing brace, so a braced default leaves a stray } glued onto the real flag.
if [ -z "${FLAG:-}" ]; then
    FLAG='SkillBit{Fake_Flag_For_Testing}'
fi
RAND="$(head -c 8 /dev/urandom | od -An -tx1 | tr -d ' \n')"
FLAG_FILE="/flag-${RAND}.txt"

printf '%s\n' "$FLAG" > "$FLAG_FILE"
# World readable on purpose: the web user has to be able to read it once the
# intended code execution lands.
chmod 644 "$FLAG_FILE"
unset FLAG

# Apache logs to /dev/stdout and /dev/stderr, which it reopens through /proc/self/fd
# after the drop below. The runtime hands those pipes to the container owned by root,
# so give them to the app user or Apache exits with "Unable to open logs".
# Do not redirect this command: /proc/self/fd is resolved by chown itself, so a
# `2>/dev/null` here would hand it /dev/null instead of the real stderr pipe.
chown "${APP_UID}:${APP_GID}" /proc/self/fd/1 /proc/self/fd/2 || true

# Only the flag write above needed root. Apache listens on 8080, which is
# unprivileged, so hand the server over to the app user before it serves a request.
exec setpriv --reuid="${APP_UID}" --regid="${APP_GID}" --init-groups apache2-foreground
