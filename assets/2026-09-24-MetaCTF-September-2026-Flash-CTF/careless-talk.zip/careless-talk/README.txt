Careless Talk
=============

careless-talk is a 64-bit Linux ELF executable.

    chmod +x careless-talk
    ./careless-talk
