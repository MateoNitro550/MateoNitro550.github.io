#!/bin/bash

echo -e "\n${YELLOW}================= GitSleuth Quest =================${NC}"
echo -e "${YELLOW}[?] A mysterious repository holds ancient secrets...${NC}"
echo -e "${YELLOW}[!] Your mission: Uncover the sacred text within${NC} ${RED}/flag.txt${NC}"
echo -e "${YELLOW}[*] Use your git-fu wisely, brave adventurer${NC}"
echo -e "${YELLOW}=================================================${NC}\n"

python3 challenge.py
