#!/bin/bash

# General configs
git config --global --add safe.directory /tmp
git config --global user.email "zAbuQasem@metactf.com"
git config --global user.name "zAbuQasem"
git config --global init.defaultBranch main

# Adding alot of files
c=1
flag='SkillBit{This_Is_A_Fake_Flag}'


while [[ "${c}" -le 500 ]]; do
  echo "${flag}" > /tmp/"$(head -n 10 /dev/urandom | md5sum | cut -d ' ' -f1)".txt
  c=$((c + 1))
done

cp /flag.txt /tmp/"$(head -n 10 /dev/urandom | md5sum | cut -d ' ' -f1)".txt

while true; do
    socat -t60 -T60 TCP-LISTEN:1337,reuseaddr,fork SYSTEM:'sh entrypoint.sh'
done
