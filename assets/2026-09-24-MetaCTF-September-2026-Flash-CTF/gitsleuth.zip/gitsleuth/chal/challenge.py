import subprocess

DISALLOWED_CHARS = ["|", "\"", "'", ";", "$", "\\", "#", "*", "(", ")", "&", "^", "@", "!", "<", ">", "%", ":", ",", "?", "{", "}", "`","diff","/dev/null","patch","./","alias","push","grep","Fake","Flag","For","Testing","flag","work","remote","update-ref","lfs-remote"]

def validate_utf8(input_text):
    try:
        input_text.encode('utf-8').decode('utf-8')
        return True
    except UnicodeDecodeError:
        return False

def collect_git_commands():
    git_commands = []
    print("Please enter git commands (Press Enter on an empty line to finish):")
    while True:
        try:
            user_input = input("")
        except (EOFError, KeyboardInterrupt):
            break

        if not user_input:
            break

        if not validate_utf8(user_input):
            print("Invalid input detected. Please try again! 💪")
            exit(1337)

        for cmd in user_input.split(" "):
            for disallowed in DISALLOWED_CHARS:
                if disallowed in cmd:
                    print("Invalid command detected. Please try again! 💪")
                    exit(1337)

        git_commands.append(user_input)

    return git_commands

def run_git_commands(git_commands):
    for cmd in git_commands:
        try:
            result = subprocess.run(["git"] + cmd.split(), check=True, text=True, capture_output=True)
            print(result.stdout)
        except subprocess.CalledProcessError as e:
            print(f"Error executing command: {e}")
            print(e.stderr)

commands = collect_git_commands()
run_git_commands(commands)
